USE auxiliary;
DROP TABLE swieta;

USE master;

DROP DATABASE auxiliary;

GO
