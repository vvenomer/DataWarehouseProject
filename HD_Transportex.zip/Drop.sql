use HD_Transportex
DROP TABLE PackageStatuses;
DROP TABLE Packages;
DROP TABLE Courses;
DROP TABLE Couriers;
DROP TABLE Magazines;
DROP TABLE PackageTypes;
DROP TABLE Clients;