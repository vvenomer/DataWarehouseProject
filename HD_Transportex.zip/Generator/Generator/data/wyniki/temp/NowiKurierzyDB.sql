UPDATE dbo.Couriers SET Surname='Janiszewska' WHERE Name='Resina' AND Surname='Sikorska';
