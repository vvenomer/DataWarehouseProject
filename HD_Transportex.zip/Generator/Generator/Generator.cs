﻿namespace Generator
{
    using System.IO;

    public static class Generator
    {
        public static string Path = @"..\..\..\data\";
    }
}