use HD_Transportex_HD
DROP TABLE Packages
DROP TABLE Courses
DROP TABLE Couriers
DROP TABLE Magazines
DROP TABLE PackageTypes
DROP TABLE Clients
DROP TABLE MyTime
DROP TABLE MyDate
DROP TABLE Addresses